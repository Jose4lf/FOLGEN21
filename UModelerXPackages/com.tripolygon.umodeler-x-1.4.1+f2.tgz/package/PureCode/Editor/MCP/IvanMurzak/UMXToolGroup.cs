using System.ComponentModel;
using System.Threading.Tasks;
using com.IvanMurzak.McpPlugin;
using UnityEngine;

namespace Tripolygon.UModelerX.Editor.MCP.IvanMurzak
{
    // IvanMurzak/Unity-MCP(com.ivanmurzak.unity.mcp) 어댑터.
    // 프로토콜 변환만 담당하고 실제 실행은 Core 의 *Operation 으로 위임.
    // 메서드 시그니처는 프레임워크가 JSON 스키마로 자동 변환하므로 그대로 유지한다.
    [McpPluginToolType]
    public class UMXToolGroup
    {
        [McpPluginTool("umx_parametric_shape", Title = "UModelerX / Parametric Shape")]
        [Description(UMXMcpUtility.SceneToolDescription)]
        public Task<object> Scene(
            [Description("Line-based UModelerX scene DSL script.")]
            string script)
        {
            return UMXMcpUtility.RunOnMainThread<object>(() => ToResponse(UMXSceneOperation.Execute(script)));
        }

        [McpPluginTool("umx_scene_dump", Title = "UModelerX / Dump Scene As DSL")]
        [Description(UMXMcpUtility.SceneDumpToolDescription)]
        public Task<object> SceneDump(
            [Description("Optional. \"name\" or #id — dump only that object and its children.")]
            string target,
            [Description("Optional. 'scene' (default) or 'selection'.")]
            string scope)
        {
            return UMXMcpUtility.RunOnMainThread<object>(() => ToResponse(UMXSceneDumpOperation.Execute(target, scope)));
        }

        [McpPluginTool("umx_hotspot", Title = "UModelerX / Hotspot Layout")]
        [Description(UMXMcpUtility.HotspotToolDescription)]
        public Task<object> Hotspot(
            [Description("Line-based UModelerX hotspot layout DSL script.")]
            string script)
        {
            return UMXMcpUtility.RunOnMainThread<object>(() => ToResponse(UMXHotspotOperation.Execute(script)));
        }

        [McpPluginTool("umx_picoberry_generate", Title = "UModelerX / PicoBerry Generate")]
        [Description(UMXPicoBerryToolText.GenerateDescription)]
        // ⚠️ IvanMurzak 프레임워크는 선택 파라미터 기본값을 스키마로 표현하지 못한다.
        //    texture 를 안 주면 false 가 오므로, 다른 어댑터(미지정 시 true)와 결과가 달라진다.
        //    그래서 이 파라미터만 TextureParamRequiredExplicit 을 써서 에이전트가 보는 설명
        //    자체에 명시적으로 넘겨야 한다고 못박아 둔다.
        public Task<object> PicoBerryGenerate(
            [Description(UMXPicoBerryToolText.PromptParam)] string prompt,
            [Description(UMXPicoBerryToolText.ImagePathParam)] string imagePath,
            [Description(UMXPicoBerryToolText.ModelParam)] string model,
            [Description(UMXPicoBerryToolText.TextureParamRequiredExplicit)] bool texture,
            [Description(UMXPicoBerryToolText.HighResTextureParam)] bool highResTexture,
            [Description(UMXPicoBerryToolText.TPoseParam)] bool tPose,
            [Description(UMXPicoBerryToolText.PolygonCountParam)] int polygonCount,
            [Description(UMXPicoBerryToolText.NameParam)] string name,
            [Description(UMXPicoBerryToolText.PositionParam)] string position,
            [Description(UMXPicoBerryToolText.RotationParam)] string rotation,
            [Description(UMXPicoBerryToolText.ScaleParam)] string scale,
            [Description(UMXPicoBerryToolText.ParentParam)] string parent)
        {
            var buildError = UMXPicoBerryRequestBuilder.BuildGenerate(
                prompt: prompt,
                imagePath: imagePath,
                model: model,
                texture: texture,
                highResTexture: highResTexture,
                tPose: tPose,
                polygonCount: polygonCount,
                name: name,
                position: position,
                rotation: rotation,
                scale: scale,
                parent: parent,
                out var request);

            if (buildError != null) return Task.FromResult(ToResponse(buildError));

            return UMXMcpUtility.RunOnMainThread<object>(
                () => ToResponse(PicoBerryGenerateOperation.Execute(request)));
        }

        [McpPluginTool("umx_picoberry_status", Title = "UModelerX / PicoBerry Status")]
        [Description(UMXPicoBerryToolText.StatusDescription)]
        public Task<object> PicoBerryStatus(
            [Description(UMXPicoBerryToolText.SessionIdParam)] string sessionId)
        {
            var request = new PicoBerryStatusRequest { SessionId = sessionId };
            return UMXMcpUtility.RunOnMainThread<object>(
                () => ToResponse(PicoBerryStatusOperation.Execute(request)));
        }

        [McpPluginTool("umx_picoberry_wait", Title = "UModelerX / PicoBerry Wait")]
        [Description(UMXPicoBerryToolText.WaitDescription)]
        public Task<object> PicoBerryWait(
            [Description(UMXPicoBerryToolText.SessionIdParam)] string sessionId,
            [Description(UMXPicoBerryToolText.TimeoutSecondsParam)] int timeoutSeconds)
        {
            var request = new PicoBerryWaitRequest
            {
                SessionId = sessionId,
                TimeoutSeconds = timeoutSeconds > 0
                    ? timeoutSeconds
                    : PicoBerryWaitRequest.DefaultTimeoutSeconds,
            };
            return UMXMcpUtility.RunOnMainThreadAsync<object>(
                async () => ToResponse(await PicoBerryWaitOperation.ExecuteAsync(request)));
        }

        [McpPluginTool("umx_picoberry_place", Title = "UModelerX / PicoBerry Place")]
        [Description(UMXPicoBerryToolText.PlaceDescription)]
        public Task<object> PicoBerryPlace(
            [Description(UMXPicoBerryToolText.SessionIdParam)] string sessionId,
            [Description(UMXPicoBerryToolText.AssetIdParam)] string assetId,
            [Description(UMXPicoBerryToolText.NameParam)] string name,
            [Description(UMXPicoBerryToolText.PositionParam)] string position,
            [Description(UMXPicoBerryToolText.RotationParam)] string rotation,
            [Description(UMXPicoBerryToolText.ScaleParam)] string scale,
            [Description(UMXPicoBerryToolText.ParentParam)] string parent)
        {
            var buildError = UMXPicoBerryRequestBuilder.BuildPlace(
                sessionId: sessionId,
                assetId: assetId,
                name: name,
                position: position,
                rotation: rotation,
                scale: scale,
                parent: parent,
                out var request);

            if (buildError != null) return Task.FromResult(ToResponse(buildError));

            return UMXMcpUtility.RunOnMainThreadAsync<object>(
                async () => ToResponse(await PicoBerryPlaceOperation.ExecuteAsync(request)));
        }

        [McpPluginTool("umx_picoberry_list", Title = "UModelerX / PicoBerry List")]
        [Description(UMXPicoBerryToolText.ListDescription)]
        public Task<object> PicoBerryList(
            [Description(UMXPicoBerryToolText.QueryParam)] string query,
            [Description(UMXPicoBerryToolText.PageParam)] int page,
            [Description(UMXPicoBerryToolText.LimitParam)] int limit)
        {
            var request = new PicoBerryListRequest
            {
                Query = query,
                Page = page,
                Limit = limit > 0 ? limit : PicoBerryListRequest.DefaultLimit,
            };
            return UMXMcpUtility.RunOnMainThreadAsync<object>(
                async () => ToResponse(await PicoBerryListOperation.ExecuteAsync(request)));
        }

        // IvanMurzak 프레임워크의 ReflectorNet 이 익명 타입을 거부할 수 있어 단순 컨테이너로 변환.
        private static object ToResponse(UMXMcpResult result)
        {
            return result.Success
                ? (object)new { success = true, message = result.Message, data = result.Data }
                : new { success = false, error = result.Message };
        }
    }
}
