using System.Threading.Tasks;
using MCPForUnity.Editor.Tools;
using Newtonsoft.Json.Linq;

namespace Tripolygon.UModelerX.Editor.MCP.Coplay
{
    // CoplayDev MCP 용 씬 덤프 커맨드.
    // 프로토콜 변환만 담당하고 실제 실행은 UMXSceneDumpOperation 으로 위임.
    [McpForUnityTool("umx_scene_dump", Description = UMXMcpUtility.SceneDumpToolDescription)]
    public static class SceneDumpCommand
    {
        // 중첩 Parameters 클래스가 없으면 스키마 properties 가 비어 파라미터 매핑이 안 되고
        // execute_custom_tool 경유가 강제된다 — ToolDiscoveryService 가 이 클래스에서 스키마를 추출한다.
        public class Parameters
        {
            [ToolParameter("Optional. \"name\" or #id — dump only that object and its children.")]
            public string target { get; set; }

            [ToolParameter("Optional. 'scene' (default) or 'selection'.")]
            public string scope { get; set; }
        }

        public static Task<object> HandleCommand(JObject @params)
        {
            @params ??= new JObject();
            var target = @params["target"]?.ToString();
            var scope = @params["scope"]?.ToString();
            var result = UMXSceneDumpOperation.Execute(target, scope);
            return Task.FromResult(CoplayMcpAdapter.ToResponse(result));
        }
    }
}
