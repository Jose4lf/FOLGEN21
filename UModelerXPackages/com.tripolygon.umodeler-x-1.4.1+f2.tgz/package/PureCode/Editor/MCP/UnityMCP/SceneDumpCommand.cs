using System.Threading.Tasks;
using Unity.AI.MCP.Editor.Helpers;
using Unity.AI.MCP.Editor.ToolRegistry;

namespace Tripolygon.UModelerX.Editor.MCP
{
    public class SceneDumpParams
    {
        [McpDescription("Optional. \"name\" or #id — dump only that object and its children.")]
        public string Target { get; set; }

        [McpDescription("Optional. 'scene' (default) or 'selection'.")]
        public string Scope { get; set; }
    }

    // Unity.AI.MCP 어댑터. 프로토콜 변환만 담당하고 실제 실행은 UMXSceneDumpOperation 으로 위임.
    [McpTool(
        name: "umx_scene_dump",
        description: UMXMcpUtility.SceneDumpToolDescription,
        title: "UModelerX: Dump Scene As DSL")]
    public class SceneDumpCommand : IUnityMcpTool<SceneDumpParams>
    {
        public Task<object> ExecuteAsync(SceneDumpParams parameters)
        {
            parameters ??= new SceneDumpParams();
            var result = UMXSceneDumpOperation.Execute(parameters.Target, parameters.Scope);
            object response = result.Success
                ? Response.Success(result.Message, result.Data)
                : Response.Error(result.Message);
            return Task.FromResult(response);
        }
    }
}
