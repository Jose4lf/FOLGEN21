using Tripolygon.UModelerX.Editor.MCP;
using Unity.Pipeline.Commands;

namespace Tripolygon.UModelerX.Editor.Pipeline
{
    // Unity Pipeline 어댑터. 프로토콜 변환만 담당하고 실제 실행은 UMXSceneOperation 으로 위임.
    static class SceneCommands
    {
        const string ScriptArgDescription = "Line-based UModelerX scene DSL script.";

        // [CliCommand] 인자로 쓰이므로 compile-time const 여야 한다.
        const string ValidateDescription =
            "umx_scene_validate — Parse a umx_scene_apply script and report what is wrong with it.\n"
            + "Read-only: it changes nothing, so it is safe to call before umx_scene_apply.\n"
            + "Takes the same `script` DSL — see umx_scene_apply for the full syntax.";

        [CliCommand(
            "umx_scene_apply",
            UMXMcpUtility.SceneToolDescription,
            Tags = new[] { "umodelerx/scene" })]
        public static object Apply(
            [CliArg("script", ScriptArgDescription, Required = true)] string script)
        {
            return UMXPipelineResponse.Unwrap(UMXSceneOperation.Execute(script));
        }

        [CliCommand(
            "umx_scene_validate",
            ValidateDescription,
            Tags = new[] { "umodelerx/scene" })]
        public static object Validate(
            [CliArg("script", ScriptArgDescription, Required = true)] string script)
        {
            return UMXPipelineResponse.Unwrap(UMXSceneOperation.Validate(script));
        }
    }
}
